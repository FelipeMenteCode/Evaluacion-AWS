<?php
    $c=mysqli_connect("database-1.cc4m8v3sl9at.us-east-1.rds.amazonaws.com","pi","inacap2026","test4");

?>
