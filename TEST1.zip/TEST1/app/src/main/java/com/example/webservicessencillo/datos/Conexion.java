package com.example.webservicessencillo.datos;


public class Conexion {
    public static final String URL_WEB_SERVICES ="http://10.38.69.198/test1/";
}
