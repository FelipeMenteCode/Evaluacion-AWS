package com.example.webservicessencillo;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

// Librerías de Volley
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

// Tu clase de conexión
import com.example.webservicessencillo.datos.Conexion;

public class MainActivity extends AppCompatActivity {

    EditText etUsuario, etPassword;
    Button btnIngresar, btnLimpiar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsuario = findViewById(R.id.etUsuario);
        etPassword = findViewById(R.id.etPassword);
        btnIngresar = findViewById(R.id.btnIngresar);
        btnLimpiar = findViewById(R.id.btnLimpiar);

        btnLimpiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etUsuario.setText("");
                etPassword.setText("");
            }
        });

        btnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String usuario = etUsuario.getText().toString().trim();
                final String password = etPassword.getText().toString().trim();

                if (usuario.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Error: Debe completar todos los campos", Toast.LENGTH_SHORT).show();
                } else {
                    validar(usuario, password);
                }
            }
        });
    }

    public void validar(String usuario, String password) {
        // Armamos la URL disfrazando tus datos para que el PHP de la Raspberry no colapse
        String url = Conexion.URL_WEB_SERVICES + "ingreso.php?nombre=" + usuario
                + "&apellido=" + password
                + "&direccion=SinDireccion"
                + "&telefono=0"
                + "&correo=SinCorreo"
                + "&sexo=ND"
                + "&fecha=Hoy";

        RequestQueue servicio = Volley.newRequestQueue(this);
        StringRequest respuesta = new StringRequest(
                Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "¡Registro insertado exitoso en AWS!", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Error: " + error.toString(), Toast.LENGTH_LONG).show();
            }
        });

        servicio.add(respuesta);
    }
}